# Ubunwan APT repository

- `deb` manpage
- https://blog.serverdensity.com/how-to-create-a-debian-deb-package/
- https://linuxconfig.org/easy-way-to-create-a-debian-package-and-local-package-repository
- https://blog.packagecloud.io/eng/2017/03/23/create-debian-repository-reprepro/

## Description

This repository contains Ubunwan debian packages and a Dockerfile to deploy an APT server in a container.

## Build a package

```sh
apt-repository/packages $

    tree
        .
        └── ubunwan-test
            ├── DEBIAN
            │   ├── conffiles    # tag files as conf files, removed only on purge
            │   ├── control      # debian package informations
            │   ├── postinst     # script executed after installation
            │   ├── postrm       # script executed after removal
            │   ├── preinst      # script executed before installation
            │   └── prerm        # script executed before removal
            └── usr
                └── local
                    ├── bin
                    │   └── ubunwan-test_print
                    └── etc
                        └── ubunwan-test_helloworld

    dpkg -b ubunwan-test [ubunwan-test-0.0.0.deb]
```

## Add packages to the repository

```sh
apt-repository $

    dpkg-scanpackages packages | gzip -c9  > Packages.gz
```

## Deploy the server

```sh
apt-repository $

    docker build . -t ubunwan_apt_server
    docker run -t ubunwan_apt_server
```

